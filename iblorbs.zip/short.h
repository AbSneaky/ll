char *ShortProgramName(char *argv);
